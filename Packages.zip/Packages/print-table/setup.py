from setuptools import setup
setup(name='print_table',
    version='0.1',
    description='Imprime una lista de lista o lista de tuplas en formato de tabla',
    url='#',
    author='rctorr',
    author_email='rctorr@cuhrt.com',
    license='MIT',
    packages=['print_table'],
    zip_safe=False
)

