from setuptools import setup
setup(name='lst',
    version='0.1',
    description='Lista los archivos de tipo texto dada una carpeta',
    url='#',
    author='rctorr',
    author_email='rctorr@cuhrt.com',
    license='MIT',
    packages=['lst'],
    zip_safe=False
)

